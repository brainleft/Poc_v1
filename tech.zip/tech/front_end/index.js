var express = require('express')
const {createProxyMiddleware} = require('http-proxy-middleware');
var app = express()

app.use('/public', express.static('public')) // static resourses
//api子目录下的都是用8080代理
// 在我的源代码后端是8080端口开启 其中有两个controller  UserController  TestController
//UserController requestMapping是"/api"  访问http://localhost/api/users 相当于访问 http://localhost:8080/api/users

const apiProxy = createProxyMiddleware('/', { target: 'http://localhost:8080',changeOrigin: true});
app.use('/*', apiProxy);


console.log(__dirname+ "/src/" + "list.html")

app.get('/list.html', function (req, res) {
    console.log("1111111111")
    res.sendFile( __dirname + "/src/" + "list.html" )
 })
 
 app.get('/login.html', function (req, res) {
    console.log("22222222")
     res.sendFile( __dirname + "/src/" + "login.html" )
 })

 app.get('/index.html', function (req, res) {
    res.sendFile( __dirname + "/src/" + "index.html" );
 })
 
 app.listen(8003,function(){
     console.log('connect successfully')
 })