To realize node.js + springboot 
1.npm install express
2.npm install http-proxy-middleware
3.npm init // create package.json file
4.define node.js --> index.js
