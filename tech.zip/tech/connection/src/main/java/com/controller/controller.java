package com.controller;

import com.domin.client;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;


@RestController
public class controller {

    @ResponseBody
    @GetMapping("/client")
    public List<client> listClient(){
        List<client> list = new ArrayList<>();
        list.add(new client(1, "clientApple"));
        list.add(new client(2, "clientCat"));
        return list;
    }
}
