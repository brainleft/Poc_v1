package com.producer;


import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

import java.io.IOException;
import java.util.concurrent.TimeoutException;


public class workqueue_producer {
    public static void main(String[] args) throws IOException, TimeoutException {
        //create connectionFactory
        ConnectionFactory factory = new ConnectionFactory();
        //set parameter
        //factory.setHost("localhost");
        factory.setPort(5672);
        factory.setVirtualHost("/turkey");
        factory.setUsername("turkey");
        factory.setPassword("turkey");
        //create connection
        Connection connection = factory.newConnection();

        // create channel
        Channel channel = connection.createChannel();
        //create queue
        channel.queueDeclare("work_queues", true, false, false, null);
        for(int i = 1; i <= 10; i++){
            String body = i + "hello rabbitmq";
            channel.basicPublish("", "work_queues", null, body.getBytes());
        }
        //sent message to queue



        channel.close();
        connection.close();
    }
}

