package com.producer;


import com.rabbitmq.client.BuiltinExchangeType;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

import java.io.IOException;
import java.util.concurrent.TimeoutException;


public class topics_producer {
    public static void main(String[] args) throws IOException, TimeoutException {
        ConnectionFactory factory = new ConnectionFactory();
        factory.setPort(5672);
        factory.setVirtualHost("/turkey");
        factory.setUsername("turkey");
        factory.setPassword("turkey");
        Connection connection = factory.newConnection();
        Channel channel = connection.createChannel();

        //exchange
        String exchangName = "test_topic";
        channel.exchangeDeclare(exchangName, BuiltinExchangeType.TOPIC, true, false, false, null);

        //queue 2
        String queue1Name = "test_topic_queue1";
        String queue2Name = "test_topic_queue2";
        channel.queueDeclare(queue1Name, true, false, false, null);
        channel.queueDeclare(queue2Name, true, false, false, null);
        //binding exchange and queue
        //systemName.infoLevel
        channel.queueBind(queue1Name, exchangName, "#.error");
        channel.queueBind(queue1Name, exchangName, "order.*");
        channel.queueBind(queue2Name, exchangName, "*.*");
        //send message
        String body = "loginfo: zhangsan use findall method, info......";
        channel.basicPublish(exchangName, "order.info", null, body.getBytes());

        channel.close();
        connection.close();


    }
}

