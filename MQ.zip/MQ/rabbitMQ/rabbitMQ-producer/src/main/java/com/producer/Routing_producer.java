package com.producer;


import com.rabbitmq.client.BuiltinExchangeType;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

import java.io.IOException;
import java.util.concurrent.TimeoutException;


public class Routing_producer {
    public static void main(String[] args) throws IOException, TimeoutException {
        ConnectionFactory factory = new ConnectionFactory();
        factory.setPort(5672);
        factory.setVirtualHost("/turkey");
        factory.setUsername("turkey");
        factory.setPassword("turkey");
        Connection connection = factory.newConnection();
        Channel channel = connection.createChannel();

        //exchange
        String exchangName = "test_direct";
        channel.exchangeDeclare(exchangName, BuiltinExchangeType.DIRECT, true, false, false, null);

        //queue 2
        String queue1Name = "test_direct_queue1";
        String queue2Name = "test_direct_queue2";
        channel.queueDeclare(queue1Name, true, false, false, null);
        channel.queueDeclare(queue2Name, true, false, false, null);
        //binding exchange and queue
        channel.queueBind(queue1Name, exchangName, "error");
        channel.queueBind(queue2Name, exchangName, "info");
        channel.queueBind(queue2Name, exchangName, "error");
        channel.queueBind(queue2Name, exchangName, "warning");
        //send message
        String body = "loginfo: zhangsan use findall method, info......";
        channel.basicPublish(exchangName, "error", null, body.getBytes());

        channel.close();
        connection.close();


    }
}

