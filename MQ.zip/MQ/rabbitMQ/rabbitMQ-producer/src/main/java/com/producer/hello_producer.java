package com.producer;


import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

import java.io.IOException;
import java.util.concurrent.TimeoutException;


public class hello_producer {
    public static void main(String[] args) throws IOException, TimeoutException {
        //create connectionFactory
        ConnectionFactory factory = new ConnectionFactory();
        //set parameter
        //factory.setHost("localhost");
        factory.setPort(5672);
        factory.setVirtualHost("/turkey");
        factory.setUsername("turkey");
        factory.setPassword("turkey");
        //create connection
        Connection connection = factory.newConnection();

        // create channel
        Channel channel = connection.createChannel();
        //create queue
        channel.queueDeclare("hello_world", true, false, false, null);

        //sent message to queue
        String body = "hello rabbitmq";
        channel.basicPublish("", "hello_world", null, body.getBytes());

        channel.close();
        connection.close();
    }
}

