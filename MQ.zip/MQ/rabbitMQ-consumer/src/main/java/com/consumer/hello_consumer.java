package com.consumer;

import com.rabbitmq.client.*;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

public class hello_consumer {
    public static void main(String[] args) throws IOException, TimeoutException {
        ConnectionFactory factory = new ConnectionFactory();

        factory.setPort(5672);
        factory.setVirtualHost("/turkey");
        factory.setUsername("turkey");
        factory.setPassword("turkey");

        Connection connection = factory.newConnection();


        Channel channel = connection.createChannel();

        channel.queueDeclare("hello_world", true, false, false, null);
        Consumer consumer = new DefaultConsumer(channel){
            // consumerTag : TAG
            // ENVELOPE: INFORMATION OF SWITCH ROUTER
            //properties: configuration
            //body: data

            @Override
            public void handleDelivery(String consumerTag, Envelope envelope, AMQP.BasicProperties properties, byte[] body) throws IOException {
                System.out.println("consumerTage:" + consumerTag);
                System.out.println("exchange:" + envelope.getExchange());
                System.out.println("routingKey:" + envelope.getRoutingKey());
                System.out.println("properties:" + properties);
                System.out.println("body:" + new String(body));

            }
            //call back method, when receive the message, will call this function automatically
        };

        channel.basicConsume("hello_world", true, consumer);
        //consumer need not close the resoures
        //connection.close();

    }
}
