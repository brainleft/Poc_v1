package com.consumer;

import com.rabbitmq.client.*;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

public class hubsub1_consumer {
    public static void main(String[] args) throws IOException, TimeoutException {
        ConnectionFactory factory = new ConnectionFactory();

        factory.setPort(5672);
        factory.setVirtualHost("/turkey");
        factory.setUsername("turkey");
        factory.setPassword("turkey");

        Connection connection = factory.newConnection();


        Channel channel = connection.createChannel();

        channel.queueDeclare("test_fanout_queue1", true, false, false, null);
        Consumer consumer = new DefaultConsumer(channel){
            // consumerTag : TAG
            // ENVELOPE: INFORMATION OF SWITCH ROUTER
            //properties: configuration
            //body: data

            @Override
            public void handleDelivery(String consumerTag, Envelope envelope, AMQP.BasicProperties properties, byte[] body) throws IOException {
                System.out.println("body:" + new String(body));
                System.out.println("input the loginfo to console");

            }
            //call back method, when receive the message, will call this function automatically
        };

        channel.basicConsume("test_fanout_queue1", true, consumer);
        //consumer need not close the resoures
        //connection.close();

    }
}
